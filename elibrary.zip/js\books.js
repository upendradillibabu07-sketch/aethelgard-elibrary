// Book collection CRUD management with localStorage persistence
import { initialBooks } from "./data.js";

const BOOKS_KEY = "elibrary_books";

// Initialize books repository
export function initBooks() {
  const books = localStorage.getItem(BOOKS_KEY);
  if (!books) {
    localStorage.setItem(BOOKS_KEY, JSON.stringify(initialBooks));
  }
}

export function getAllBooks() {
  initBooks();
  return JSON.parse(localStorage.getItem(BOOKS_KEY));
}

export function getBookById(id) {
  const books = getAllBooks();
  return books.find(b => b.id === id) || null;
}

export function addBook(bookData) {
  const books = getAllBooks();
  
  // Generate random rich gradient color for the new book cover
  const gradients = [
    { background: "linear-gradient(135deg, #11998e 0%, #38ef7d 100%)", color: "#1c1c1c", accent: "#1c1c1c" },
    { background: "linear-gradient(135deg, #8a252c 0%, #4a1014 100%)", color: "#ffffff", accent: "#d4af37" },
    { background: "linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)", color: "#ffffff", accent: "#ffd700" },
    { background: "linear-gradient(135deg, #e65c00 0%, #f9d423 100%)", color: "#3e1200", accent: "#3e1200" },
    { background: "linear-gradient(135deg, #2b5876 0%, #4e4376 100%)", color: "#ffffff", accent: "#dfba73" },
    { background: "linear-gradient(135deg, #7b4397 0%, #dc2430 100%)", color: "#ffffff", accent: "#f5d300" }
  ];
  const randomGradient = gradients[Math.floor(Math.random() * gradients.length)];

  const newBook = {
    id: `book-${Date.now()}`,
    title: bookData.title,
    author: bookData.author,
    genre: bookData.genre,
    description: bookData.description || "No description provided.",
    publishedYear: parseInt(bookData.publishedYear) || new Date().getFullYear(),
    rating: parseFloat(bookData.rating) || 5.0,
    coverStyle: bookData.coverStyle || randomGradient,
    isAvailable: true
  };

  books.push(newBook);
  localStorage.setItem(BOOKS_KEY, JSON.stringify(books));
  return newBook;
}

export function updateBook(id, updatedData) {
  const books = getAllBooks();
  const index = books.findIndex(b => b.id === id);
  
  if (index === -1) {
    throw new Error("Book not found");
  }

  // Preserve coverStyle and isAvailable unless explicitly overwritten
  books[index] = {
    ...books[index],
    title: updatedData.title,
    author: updatedData.author,
    genre: updatedData.genre,
    description: updatedData.description,
    publishedYear: parseInt(updatedData.publishedYear) || books[index].publishedYear,
    rating: parseFloat(updatedData.rating) || books[index].rating,
    coverStyle: updatedData.coverStyle || books[index].coverStyle,
    isAvailable: updatedData.isAvailable !== undefined ? updatedData.isAvailable : books[index].isAvailable
  };

  localStorage.setItem(BOOKS_KEY, JSON.stringify(books));
  return books[index];
}

export function deleteBook(id) {
  const books = getAllBooks();
  const filtered = books.filter(b => b.id !== id);
  
  if (books.length === filtered.length) {
    throw new Error("Book not found");
  }

  localStorage.setItem(BOOKS_KEY, JSON.stringify(filtered));
}

// Helper to toggle availability status directly
export function toggleAvailability(id, isAvailable) {
  const books = getAllBooks();
  const index = books.findIndex(b => b.id === id);
  if (index !== -1) {
    books[index].isAvailable = isAvailable;
    localStorage.setItem(BOOKS_KEY, JSON.stringify(books));
  }
}
