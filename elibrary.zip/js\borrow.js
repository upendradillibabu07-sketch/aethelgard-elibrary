// Borrowing transaction logic with localStorage persistence
import { toggleAvailability, getBookById } from "./books.js";

const BORROWS_KEY = "elibrary_borrows";

// Get all borrow transactions
export function getAllBorrows() {
  return JSON.parse(localStorage.getItem(BORROWS_KEY)) || [];
}

// Borrow a book
export function borrowBook(userId, bookId) {
  const book = getBookById(bookId);
  if (!book) {
    throw new Error("Book not found.");
  }
  if (!book.isAvailable) {
    throw new Error("Book is already borrowed by someone else.");
  }

  const borrows = getAllBorrows();
  const borrowDate = new Date();
  
  // Set due date to 14 days from now
  const dueDate = new Date();
  dueDate.setDate(borrowDate.getDate() + 14);

  const newBorrow = {
    id: `borrow-${Date.now()}`,
    userId,
    bookId,
    borrowDate: borrowDate.toISOString(),
    dueDate: dueDate.toISOString(),
    returnedDate: null
  };

  borrows.push(newBorrow);
  localStorage.setItem(BORROWS_KEY, JSON.stringify(borrows));
  
  // Update book availability status to false
  toggleAvailability(bookId, false);

  return newBorrow;
}

// Return a book
export function returnBook(userId, bookId) {
  const borrows = getAllBorrows();
  const activeBorrowIndex = borrows.findIndex(
    b => b.userId === userId && b.bookId === bookId && b.returnedDate === null
  );

  if (activeBorrowIndex === -1) {
    throw new Error("No active borrow transaction found for this book and user.");
  }

  // Set return date
  borrows[activeBorrowIndex].returnedDate = new Date().toISOString();
  localStorage.setItem(BORROWS_KEY, JSON.stringify(borrows));

  // Toggle book availability back to true
  toggleAvailability(bookId, true);
}

// Get list of active borrowed books for a user, enriched with book details
export function getActiveBorrowedBooks(userId) {
  const borrows = getAllBorrows();
  const activeBorrows = borrows.filter(
    b => b.userId === userId && b.returnedDate === null
  );

  return activeBorrows.map(borrow => {
    const book = getBookById(borrow.bookId);
    return {
      ...borrow,
      // Fallback details if the book was deleted in the interim
      book: book || {
        id: borrow.bookId,
        title: "Deleted Book",
        author: "Unknown",
        genre: "Unknown",
        coverStyle: { background: "#cccccc", color: "#666" }
      }
    };
  });
}
