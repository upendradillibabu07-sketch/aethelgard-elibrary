// Authentication logic with localStorage persistence

const USERS_KEY = "elibrary_users";
const CURRENT_USER_KEY = "elibrary_current_user";

// Seed default users if not exists
export function initAuth() {
  let users = JSON.parse(localStorage.getItem(USERS_KEY));
  if (!users) {
    users = [
      {
        id: "user-admin",
        username: "Admin Librarian",
        email: "admin@elibrary.com",
        password: "admin123",
        role: "admin"
      },
      {
        id: "user-demo",
        username: "Jane Doe",
        email: "user@elibrary.com",
        password: "user123",
        role: "user"
      }
    ];
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }
}

export function getCurrentUser() {
  return JSON.parse(localStorage.getItem(CURRENT_USER_KEY)) || null;
}

export function signUp(username, email, password) {
  initAuth();
  const users = JSON.parse(localStorage.getItem(USERS_KEY));
  
  // Check if user already exists
  if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("A user with this email already exists.");
  }

  const newUser = {
    id: `user-${Date.now()}`,
    username,
    email: email.toLowerCase(),
    password, // Stored in plain text for this simple local state simulation
    role: "user" // Default role
  };

  users.push(newUser);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  
  // Automatically log in
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));
  return newUser;
}

export function login(email, password) {
  initAuth();
  const users = JSON.parse(localStorage.getItem(USERS_KEY));
  
  const user = users.find(
    u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
  );

  if (!user) {
    throw new Error("Invalid email or password.");
  }

  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  return user;
}

export function logout() {
  localStorage.removeItem(CURRENT_USER_KEY);
}
