// Seed data for the library catalog
export const initialBooks = [
  {
    id: "book-1",
    title: "The Midnight Library",
    author: "Matt Haig",
    genre: "Fiction",
    description: "Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived.",
    publishedYear: 2020,
    rating: 4.5,
    coverStyle: {
      background: "linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)",
      color: "#ffffff",
      accent: "#ffd700"
    },
    isAvailable: true
  },
  {
    id: "book-2",
    title: "Dune",
    author: "Frank Herbert",
    genre: "Sci-Fi",
    description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the spice 'melange'.",
    publishedYear: 1965,
    rating: 4.8,
    coverStyle: {
      background: "linear-gradient(135deg, #e65c00 0%, #f9d423 100%)",
      color: "#3e1200",
      accent: "#3e1200"
    },
    isAvailable: true
  },
  {
    id: "book-3",
    title: "Sapiens: A Brief History of Humankind",
    author: "Yuval Noah Harari",
    genre: "History",
    description: "From a renowned historian comes a groundbreaking narrative of humanity's creation and evolution—exploring how biology and history have defined us and enhanced our understanding of what it means to be human.",
    publishedYear: 2011,
    rating: 4.7,
    coverStyle: {
      background: "linear-gradient(135deg, #3d4a3e 0%, #95a396 100%)",
      color: "#ffffff",
      accent: "#f4e2bb"
    },
    isAvailable: true
  },
  {
    id: "book-4",
    title: "Meditations",
    author: "Marcus Aurelius",
    genre: "Philosophy",
    description: "A series of personal writings by Marcus Aurelius, Roman Emperor from 161 to 180 AD, recording his private notes to himself and ideas on Stoic philosophy.",
    publishedYear: 180,
    rating: 4.9,
    coverStyle: {
      background: "linear-gradient(135deg, #8a252c 0%, #4a1014 100%)",
      color: "#ffffff",
      accent: "#d4af37"
    },
    isAvailable: true
  },
  {
    id: "book-5",
    title: "The Silent Patient",
    author: "Alex Michaelides",
    genre: "Mystery",
    description: "Alicia Berenson's life is seemingly perfect. A famous painter married to an in-demand fashion photographer, she lives in a grand house in one of London's most desirable areas. One evening her husband returns home late, and Alicia shoots him five times in the face, and then never speaks another word.",
    publishedYear: 2019,
    rating: 4.3,
    coverStyle: {
      background: "linear-gradient(135deg, #0f2027 0%, #203a43 0%, #2c5364 100%)",
      color: "#ffffff",
      accent: "#ff3333"
    },
    isAvailable: true
  },
  {
    id: "book-6",
    title: "Atomic Habits",
    author: "James Clear",
    genre: "Self-Help",
    description: "No matter your goals, Atomic Habits offers a proven framework for improving—every day. James Clear, one of the world's leading experts on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results.",
    publishedYear: 2018,
    rating: 4.8,
    coverStyle: {
      background: "linear-gradient(135deg, #11998e 0%, #38ef7d 100%)",
      color: "#1c1c1c",
      accent: "#1c1c1c"
    },
    isAvailable: true
  },
  {
    id: "book-7",
    title: "Educated",
    author: "Tara Westover",
    genre: "Biography",
    description: "An unforgettable memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University.",
    publishedYear: 2018,
    rating: 4.6,
    coverStyle: {
      background: "linear-gradient(135deg, #7b4397 0%, #dc2430 100%)",
      color: "#ffffff",
      accent: "#f5d300"
    },
    isAvailable: true
  },
  {
    id: "book-8",
    title: "Project Hail Mary",
    author: "Andy Weir",
    genre: "Sci-Fi",
    description: "Ryland Grace is the sole survivor on a desperate, last-chance mission to save humanity. If he fails, humanity and the earth itself will perish. Except that right now, he doesn't know that. He can't even remember his own name, let alone the nature of his assignment.",
    publishedYear: 2021,
    rating: 4.7,
    coverStyle: {
      background: "linear-gradient(135deg, #000428 0%, #004e92 100%)",
      color: "#ffffff",
      accent: "#00ffff"
    },
    isAvailable: true
  },
  {
    id: "book-9",
    title: "Brave New World",
    author: "Aldous Huxley",
    genre: "Fiction",
    description: "A dystopian novel written in 1931, it propels us into the far future where genetically modified citizens are arranged in an intelligence-based social hierarchy.",
    publishedYear: 1932,
    rating: 4.4,
    coverStyle: {
      background: "linear-gradient(135deg, #5b626d 0%, #31353d 100%)",
      color: "#ffffff",
      accent: "#e07a5f"
    },
    isAvailable: true
  },
  {
    id: "book-10",
    title: "The Hobbit",
    author: "J.R.R. Tolkien",
    genre: "Fiction",
    description: "Bilbo Baggins is a hobbit who enjoys a comfortable, unambitious life, rarely traveling any farther than his pantry or cellar. But his contentment is disturbed when the wizard Gandalf and a company of dwarves arrive on his doorstep one day to enlist him on an adventure.",
    publishedYear: 1937,
    rating: 4.8,
    coverStyle: {
      background: "linear-gradient(135deg, #2d5a27 0%, #1c3b18 100%)",
      color: "#ffffff",
      accent: "#ffd700"
    },
    isAvailable: true
  },
  {
    id: "book-11",
    title: "Thinking, Fast and Slow",
    author: "Daniel Kahneman",
    genre: "Science",
    description: "Daniel Kahneman, recipient of the Nobel Prize in Economic Sciences, takes us on a groundbreaking tour of the mind and explains the two systems that drive the way we think.",
    publishedYear: 2011,
    rating: 4.6,
    coverStyle: {
      background: "linear-gradient(135deg, #f0c27b 0%, #4b1248 100%)",
      color: "#ffffff",
      accent: "#ffffff"
    },
    isAvailable: true
  },
  {
    id: "book-12",
    title: "Sherlock Holmes: Selected Stories",
    author: "Arthur Conan Doyle",
    genre: "Mystery",
    description: "A collection of the most famous cases solved by the eccentric detective Sherlock Holmes and his companion Dr. John Watson, illustrating his brilliant use of forensic science and logical deduction.",
    publishedYear: 1892,
    rating: 4.7,
    coverStyle: {
      background: "linear-gradient(135deg, #2b5876 0%, #4e4376 100%)",
      color: "#ffffff",
      accent: "#dfba73"
    },
    isAvailable: true
  }
];
