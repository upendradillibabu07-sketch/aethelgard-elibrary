// JavaScript-driven animations and micro-interactions for the E-Library

// 1. 3D Tilt Hover Effect for Book Cards
// Dynamically tilts book cards based on cursor position for a tactile, premium feel.
export function initTiltEffect() {
  document.addEventListener("mousemove", (e) => {
    const card = e.target.closest(".book-card");
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left; // cursor x coordinate within card
    const y = e.clientY - rect.top;  // cursor y coordinate within card
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    // Calculate rotation values (-10deg to 10deg)
    const rotateY = ((x - centerX) / centerX) * 10;
    const rotateX = -((y - centerY) / centerY) * 10;

    card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.04, 1.04, 1.04)`;
    card.style.boxShadow = "0 20px 40px rgba(44, 94, 67, 0.18)";
    card.style.transition = "none"; // disable transitions during manual tracking
  });

  document.addEventListener("mouseout", (e) => {
    const card = e.target.closest(".book-card");
    if (!card) return;

    // Only reset if cursor actually leaves the card container, not moving to child elements
    if (e.relatedTarget && card.contains(e.relatedTarget)) return;

    card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)";
    card.style.boxShadow = "var(--shadow-sm)";
    card.style.transition = "transform 0.5s cubic-bezier(0.25, 1, 0.5, 1), box-shadow 0.5s ease";
  });
}

// 2. Click Ripple Effect on Action Buttons
// Creates an expanding material-ripple wave relative to click position.
export function initButtonRipples() {
  document.addEventListener("mousedown", (e) => {
    const btn = e.target.closest(".btn-login, .btn-borrow, .btn-auth-submit, .btn-add-book, .btn-return, .hero-btn");
    if (!btn || btn.disabled) return;

    const rect = btn.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const ripple = document.createElement("span");
    ripple.className = "btn-ripple-wave";
    
    // Style the ripple span dynamically
    ripple.style.position = "absolute";
    ripple.style.borderRadius = "50%";
    ripple.style.pointerEvents = "none";
    
    // Theme adjustments: light buttons get darker ripples, dark buttons get white ripples
    const btnStyles = window.getComputedStyle(btn);
    const isLightBg = btn.classList.contains("btn-return") || btn.classList.contains("hero-btn");
    ripple.style.background = isLightBg ? "rgba(44, 94, 67, 0.25)" : "rgba(255, 255, 255, 0.4)";
    
    const size = Math.max(rect.width, rect.height) * 2;
    ripple.style.width = `${size}px`;
    ripple.style.height = `${size}px`;
    ripple.style.left = `${x - size / 2}px`;
    ripple.style.top = `${y - size / 2}px`;
    ripple.style.transform = "scale(0)";
    ripple.style.animation = "btn-ripple 0.5s ease-out";

    // Setup overflow container boundaries
    if (btnStyles.position === "static") {
      btn.style.position = "relative";
    }
    if (btnStyles.overflow !== "hidden") {
      btn.style.overflow = "hidden";
    }

    btn.appendChild(ripple);

    // Self cleanup
    ripple.addEventListener("animationend", () => {
      ripple.remove();
    });
  });
}

// 3. Golden Magic Sparkles Burst
// Spawns particle graphics flying in orbital directions with physics simulations.
export function triggerSparklesAt(x, y) {
  const particleCount = 28;
  const colors = ["#D4A373", "#FFD700", "#FFF3D1", "#4E8065", "#FAF7F0"];
  const shapes = ["★", "✦", "✧", "•", "✨"];
  
  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement("div");
    particle.className = "sparkle-particle";
    particle.textContent = shapes[Math.floor(Math.random() * shapes.length)];
    
    // Styling the individual dust element
    particle.style.position = "fixed";
    particle.style.left = `${x}px`;
    particle.style.top = `${y}px`;
    particle.style.color = colors[Math.floor(Math.random() * colors.length)];
    particle.style.fontSize = `${Math.random() * 15 + 8}px`;
    particle.style.pointerEvents = "none";
    particle.style.userSelect = "none";
    particle.style.zIndex = "3000";
    particle.style.opacity = "1";
    particle.style.textShadow = "0 0 4px rgba(212,163,115,0.4)";
    
    document.body.appendChild(particle);

    // Orbital trigonometry and speed components
    const angle = Math.random() * Math.PI * 2;
    const velocity = Math.random() * 8 + 4;
    const vx = Math.cos(angle) * velocity;
    const vy = Math.sin(angle) * velocity - 2.5; // slight initial anti-gravity lift
    
    let curX = x;
    let curY = y;
    let opacity = 1;
    let time = 0;
    const gravity = 0.22; // physics fall rate

    function animate() {
      time++;
      curX += vx;
      curY += vy + gravity * time;
      opacity -= 0.022; // fade factor

      particle.style.left = `${curX}px`;
      particle.style.top = `${curY}px`;
      particle.style.opacity = opacity;

      if (opacity > 0) {
        requestAnimationFrame(animate);
      } else {
        particle.remove();
      }
    }
    requestAnimationFrame(animate);
  }
}
