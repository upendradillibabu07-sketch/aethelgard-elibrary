// Main E-Library Application Controller
import { initAuth, getCurrentUser, login, signUp, logout } from "./auth.js";
import { getAllBooks, getBookById, addBook, updateBook, deleteBook } from "./books.js";
import { borrowBook, returnBook, getActiveBorrowedBooks } from "./borrow.js";
import { initTiltEffect, initButtonRipples, triggerSparklesAt } from "./animations.js";

// Global SPA view state
const state = {
  activeView: "view-home",
  searchQuery: "",
  selectedGenres: [],
  filterAvailable: true,
  filterBorrowed: true,
  sortOrder: "title-asc"
};

// Start application
document.addEventListener("DOMContentLoaded", () => {
  initAuth();
  
  // Set up SPA routing clicks
  setupRouting();
  
  // Initialize Authentication State & Nav UI
  updateAuthUI();
  
  // Bind form submissions
  setupForms();
  
  // Bind live filters & search
  setupSearchAndFilters();
  
  // Initial renders
  renderHomeView();
  renderBrowseView();
  
  // Listen for clicks on book cards (dynamic delegation)
  setupModalDelegations();

  // Initialize animations
  initTiltEffect();
  initButtonRipples();
});

// Helper: Escape HTML strings to prevent XSS
function escapeHTML(str) {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Generate book cover HTML helper
function getBookCoverHTML(book) {
  const style = book.coverStyle || {
    background: "linear-gradient(135deg, #2c5e43 0%, #183324 100%)",
    color: "#ffffff",
    accent: "#d4a373"
  };

  // Determine cover ornament icon based on genre
  let ornamentPath = "";
  const genre = (book.genre || "").toLowerCase();
  if (genre.includes("sci-fi")) {
    ornamentPath = `<polygon points="12,2 22,8.5 22,20 12,14 2,20 2,8.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>`;
  } else if (genre.includes("philosophy") || genre.includes("history")) {
    ornamentPath = `<path d="M12 2L2 22h20L12 2zm0 4v3m0 2v5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <circle cx="12" cy="18" r="1.5" fill="currentColor"/>`;
  } else if (genre.includes("mystery")) {
    ornamentPath = `<path d="M12 2v20M2 12h20" stroke="currentColor" stroke-width="1.5"/>
                    <circle cx="12" cy="12" r="6" fill="none" stroke="currentColor" stroke-width="1.5"/>`;
  } else if (genre.includes("self-help")) {
    ornamentPath = `<path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3c3.08 0 5.5 2.42 5.5 5.5 0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="none" stroke="currentColor" stroke-width="1.5"/>`;
  } else {
    // Default: Book outline
    ornamentPath = `<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20M4 19.5A2.5 2.5 0 0 0 6.5 22H20M4 19.5V3.5A2.5 2.5 0 0 1 6.5 1H20v16H6.5a2.5 2.5 0 0 0-2.5 2.5z" fill="none" stroke="currentColor" stroke-width="1.5"/>`;
  }

  return `
    <div class="book-cover" style="background: ${style.background}; color: ${style.color};">
      <div class="book-cover-border" style="border-color: ${style.accent}35;"></div>
      <div class="book-cover-author" style="color: ${style.accent};">${escapeHTML(book.author)}</div>
      <div class="book-cover-emblem" style="color: ${style.accent};">
        <svg viewBox="0 0 24 24" width="32" height="32">${ornamentPath}</svg>
      </div>
      <div class="book-cover-title">${escapeHTML(book.title)}</div>
    </div>
  `;
}

// Generate stars rating helper
function getStarsHTML(rating) {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5 ? 1 : 0;
  let stars = "";
  for (let i = 0; i < 5; i++) {
    if (i < fullStars) {
      stars += "★";
    } else if (i === fullStars && halfStar) {
      stars += "⯪";
    } else {
      stars += "☆";
    }
  }
  return stars;
}

// Toast Notifications System
export function showToast(message, type = "success") {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span>${escapeHTML(message)}</span>
    <span style="cursor:pointer; margin-left: 10px; font-weight:700;" onclick="this.parentElement.remove()">&times;</span>
  `;
  container.appendChild(toast);

  // Auto-remove after 4 seconds
  setTimeout(() => {
    toast.classList.add("toast-fade-out");
    toast.addEventListener("animationend", () => toast.remove());
  }, 4000);
}

// Route handler
function navigateTo(viewId) {
  const sections = document.querySelectorAll(".view-section");
  const links = document.querySelectorAll(".nav-link");

  sections.forEach(sec => {
    if (sec.id === viewId) {
      sec.classList.add("active");
    } else {
      sec.classList.remove("active");
    }
  });

  links.forEach(link => {
    if (link.getAttribute("data-target") === viewId) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });

  state.activeView = viewId;
  window.scrollTo({ top: 0, behavior: "smooth" });

  // Load view-specific renders
  if (viewId === "view-home") renderHomeView();
  if (viewId === "view-browse") renderBrowseView();
  if (viewId === "view-dashboard") renderDashboardView();
  if (viewId === "view-admin") renderAdminView();
}

function setupRouting() {
  // Catch nav links click
  document.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const target = link.getAttribute("data-target");
      navigateTo(target);
    });
  });

  // Logo home click
  document.getElementById("nav-logo").addEventListener("click", (e) => {
    e.preventDefault();
    navigateTo("view-home");
  });

  // Footer links click
  document.querySelectorAll(".footer-nav-link").forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const target = link.getAttribute("data-target");
      navigateTo(target);
    });
  });

  // Hero explore button click
  document.getElementById("btn-hero-browse").addEventListener("click", (e) => {
    e.preventDefault();
    navigateTo("view-browse");
  });
}

// Authentication Navigation UI Updates
function updateAuthUI() {
  const userContainer = document.getElementById("auth-nav-container");
  const dashboardLink = document.getElementById("link-dashboard");
  const adminLink = document.getElementById("link-admin");
  const currentUser = getCurrentUser();

  if (currentUser) {
    // Show links depending on role
    dashboardLink.style.display = "inline-block";
    if (currentUser.role === "admin") {
      adminLink.style.display = "inline-block";
    } else {
      adminLink.style.display = "none";
    }

    // Replace login button with Profile badge and Logout dropdown trigger
    const initials = currentUser.username
      .split(" ")
      .map(n => n[0])
      .join("")
      .substring(0, 2)
      .toUpperCase();

    userContainer.innerHTML = `
      <div style="position: relative; display: inline-block;">
        <div class="user-badge" id="btn-user-menu">
          <div class="user-avatar">${initials}</div>
          <span style="font-size:0.9rem;">${escapeHTML(currentUser.username)}</span>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-left: 2px;"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </div>
        <div class="filter-sidebar" id="user-menu-dropdown" style="display:none; position:absolute; right:0; top:42px; min-width:160px; padding:0.5rem; z-index:200; box-shadow: var(--shadow-md);">
          <ul style="display:flex; flex-direction:column; gap:0.25rem;">
            <li><a href="#" id="menu-goto-dash" style="display:block; padding:0.5rem; font-size:0.9rem; border-radius:4px; transition:var(--transition);">Bookshelf</a></li>
            ${currentUser.role === "admin" ? `<li><a href="#" id="menu-goto-admin" style="display:block; padding:0.5rem; font-size:0.9rem; border-radius:4px; transition:var(--transition);">Inventory Admin</a></li>` : ""}
            <li style="border-top: 1px solid var(--border-color); margin-top:0.25rem; padding-top:0.25rem;">
              <a href="#" id="menu-logout" style="display:block; padding:0.5rem; font-size:0.9rem; border-radius:4px; color:#e74c3c; transition:var(--transition);">Sign Out</a>
            </li>
          </ul>
        </div>
      </div>
    `;

    // Dropdown toggles
    const badge = document.getElementById("btn-user-menu");
    const dropdown = document.getElementById("user-menu-dropdown");

    badge.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    });

    document.addEventListener("click", () => {
      if (dropdown) dropdown.style.display = "none";
    });

    // Dropdown items clicks
    document.getElementById("menu-goto-dash").addEventListener("click", (e) => {
      e.preventDefault();
      navigateTo("view-dashboard");
    });

    if (currentUser.role === "admin") {
      document.getElementById("menu-goto-admin").addEventListener("click", (e) => {
        e.preventDefault();
        navigateTo("view-admin");
      });
    }

    document.getElementById("menu-logout").addEventListener("click", (e) => {
      e.preventDefault();
      logout();
      showToast("Signed out successfully.");
      // Clear navigation links
      dashboardLink.style.display = "none";
      adminLink.style.display = "none";
      updateAuthUI();
      navigateTo("view-home");
    });

  } else {
    // Guest User UI
    dashboardLink.style.display = "none";
    adminLink.style.display = "none";

    userContainer.innerHTML = `
      <button class="btn-login" id="btn-nav-login">Log In</button>
    `;

    document.getElementById("btn-nav-login").addEventListener("click", () => {
      navigateTo("view-auth");
    });
  }
}

// Authentication Forms setup
function setupForms() {
  const formLogin = document.getElementById("form-login");
  const formSignup = document.getElementById("form-signup");
  const switchToSignup = document.getElementById("switch-to-signup");
  const switchToLogin = document.getElementById("switch-to-login");
  const loginPanel = document.getElementById("auth-login-panel");
  const signupPanel = document.getElementById("auth-signup-panel");

  // Sliding switch between login and signup
  switchToSignup.addEventListener("click", () => {
    loginPanel.style.display = "none";
    signupPanel.style.display = "block";
  });

  switchToLogin.addEventListener("click", () => {
    signupPanel.style.display = "none";
    loginPanel.style.display = "block";
  });

  formLogin.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    try {
      const user = login(email, password);
      showToast(`Welcome back, ${user.username}!`);
      formLogin.reset();
      updateAuthUI();
      // Route user to Dashboard or Admin panel depending on role
      if (user.role === "admin") {
        navigateTo("view-admin");
      } else {
        navigateTo("view-dashboard");
      }
    } catch (err) {
      showToast(err.message, "error");
    }
  });

  formSignup.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("signup-username").value;
    const email = document.getElementById("signup-email").value;
    const password = document.getElementById("signup-password").value;

    try {
      const user = signUp(username, email, password);
      showToast(`Account created successfully. Welcome, ${user.username}!`);
      formSignup.reset();
      // Reset layout display toggle
      signupPanel.style.display = "none";
      loginPanel.style.display = "block";
      updateAuthUI();
      navigateTo("view-dashboard");
    } catch (err) {
      showToast(err.message, "error");
    }
  });
}

// Seeding Featured & New Arrivals in Home View
function renderHomeView() {
  const featuredGrid = document.getElementById("home-featured-grid");
  const newGrid = document.getElementById("home-new-grid");
  const books = getAllBooks();

  // 1. Featured: Sorted by rating desc, top 4
  const featuredBooks = [...books]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 4);

  // 2. New Arrivals: Sorted by published year desc, top 4
  const newBooks = [...books]
    .sort((a, b) => b.publishedYear - a.publishedYear)
    .slice(0, 4);

  featuredGrid.innerHTML = featuredBooks.map(b => getBookCardHTML(b)).join("");
  newGrid.innerHTML = newBooks.map(b => getBookCardHTML(b)).join("");
}

function getBookCardHTML(book) {
  return `
    <div class="book-card" data-id="${book.id}">
      ${getBookCoverHTML(book)}
      <div class="book-card-info">
        <span class="book-genre">${escapeHTML(book.genre)}</span>
        <h3 class="book-title" title="${escapeHTML(book.title)}">${escapeHTML(book.title)}</h3>
        <p class="book-author">by ${escapeHTML(book.author)}</p>
        <div class="book-meta">
          <div class="book-rating">
            <span>★</span>
            <span>${book.rating.toFixed(1)}</span>
          </div>
          <span class="book-status ${book.isAvailable ? "status-available" : "status-borrowed"}">
            ${book.isAvailable ? "Available" : "Borrowed"}
          </span>
        </div>
      </div>
    </div>
  `;
}

// Search and Filter logic for Browse Catalog
function setupSearchAndFilters() {
  const navSearch = document.getElementById("navbar-search-input");
  const availYes = document.getElementById("filter-avail-yes");
  const availNo = document.getElementById("filter-avail-no");
  const sortSelect = document.getElementById("catalog-sort-select");

  // Typing in navbar search switches view and filters
  navSearch.addEventListener("input", (e) => {
    state.searchQuery = e.target.value;
    if (state.activeView !== "view-browse") {
      navigateTo("view-browse");
    } else {
      renderBrowseView();
    }
  });

  // Checkbox inputs triggers filtering
  availYes.addEventListener("change", (e) => {
    state.filterAvailable = e.target.checked;
    renderBrowseView();
  });

  availNo.addEventListener("change", (e) => {
    state.filterBorrowed = e.target.checked;
    renderBrowseView();
  });

  // Sort dropdown trigger
  sortSelect.addEventListener("change", (e) => {
    state.sortOrder = e.target.value;
    renderBrowseView();
  });

  // Load dynamically seeded genres into sidebar filter checkboxes
  const books = getAllBooks();
  const genres = [...new Set(books.map(b => b.genre))].sort();
  const genreContainer = document.getElementById("genre-filter-options");

  genreContainer.innerHTML = genres
    .map(genre => `
      <label class="filter-label">
        <input type="checkbox" class="genre-filter-chk" value="${escapeHTML(genre)}" checked>
        <span>${escapeHTML(genre)}</span>
      </label>
    `)
    .join("");

  // Attach change listener to newly appended genre filters
  genreContainer.querySelectorAll(".genre-filter-chk").forEach(chk => {
    chk.addEventListener("change", () => {
      const activeCheckboxes = genreContainer.querySelectorAll(".genre-filter-chk:checked");
      state.selectedGenres = Array.from(activeCheckboxes).map(c => c.value);
      renderBrowseView();
    });
  });

  // Initial state selection matches checkboxes (all active)
  state.selectedGenres = genres;
}

function renderBrowseView() {
  const grid = document.getElementById("catalog-grid");
  const renderedCount = document.getElementById("catalog-count-rendered");
  const totalCount = document.getElementById("catalog-count-total");
  const books = getAllBooks();

  totalCount.textContent = books.length;

  // 1. FILTERING
  let filtered = books.filter(book => {
    // Search query filter
    const matchesSearch =
      book.title.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(state.searchQuery.toLowerCase()) ||
      book.genre.toLowerCase().includes(state.searchQuery.toLowerCase());

    // Status filter
    const matchesStatus =
      (book.isAvailable && state.filterAvailable) ||
      (!book.isAvailable && state.filterBorrowed);

    // Genre filter
    const matchesGenre = state.selectedGenres.includes(book.genre);

    return matchesSearch && matchesStatus && matchesGenre;
  });

  // 2. SORTING
  filtered.sort((a, b) => {
    switch (state.sortOrder) {
      case "title-asc":
        return a.title.localeCompare(b.title);
      case "title-desc":
        return b.title.localeCompare(a.title);
      case "rating-desc":
        return b.rating - a.rating;
      case "year-desc":
        return b.publishedYear - a.publishedYear;
      case "year-asc":
        return a.publishedYear - b.publishedYear;
      default:
        return 0;
    }
  });

  renderedCount.textContent = filtered.length;

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
        <h3>No books found</h3>
        <p>Try refining your search terms or adjustments to sidebar genre checkboxes.</p>
      </div>
    `;
  } else {
    grid.innerHTML = filtered.map(b => getBookCardHTML(b)).join("");
  }
}

// User Dashboard View Rendering
function renderDashboardView() {
  const user = getCurrentUser();
  if (!user) {
    navigateTo("view-auth");
    return;
  }

  document.getElementById("dashboard-welcome-msg").textContent = `Welcome back, ${user.username}`;
  document.getElementById("dashboard-role-tag").textContent = user.role === "admin" ? "Staff Librarian" : "Library Member";

  const borrowedBooks = getActiveBorrowedBooks(user.id);
  document.getElementById("stat-currently-borrowed").textContent = borrowedBooks.length;

  // Calculate overdue counts
  let overdueCount = 0;
  const now = new Date();
  
  borrowedBooks.forEach(b => {
    const dueDate = new Date(b.dueDate);
    if (now > dueDate) {
      overdueCount++;
    }
  });

  document.getElementById("stat-overdue-count").textContent = overdueCount;
  
  const overdueBox = document.getElementById("stat-overdue-container");
  if (overdueCount > 0) {
    overdueBox.parentElement.style.borderColor = "#e74c3c";
  } else {
    overdueBox.parentElement.style.borderColor = "var(--border-color)";
  }

  const listContainer = document.getElementById("dashboard-borrowed-container");
  
  if (borrowedBooks.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-state">
        <svg viewBox="0 0 24 24"><path d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0-2-.9-2-2V4c0-1.1-.9-2-2-2zm0 14H8V4h12v12z"/></svg>
        <h3>No active borrows</h3>
        <p>Browse our catalog to search and borrow your next read!</p>
      </div>
    `;
  } else {
    listContainer.innerHTML = `
      <div class="borrowed-grid">
        ${borrowedBooks.map(record => {
          const borrowDateFormatted = new Date(record.borrowDate).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
          const dueDateObj = new Date(record.dueDate);
          const dueDateFormatted = dueDateObj.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
          const isOverdue = now > dueDateObj;

          return `
            <div class="borrowed-card">
              <div class="borrowed-cover">
                ${getBookCoverHTML(record.book)}
              </div>
              <div class="borrowed-details">
                <h4 class="borrowed-title">${escapeHTML(record.book.title)}</h4>
                <p class="borrowed-author">by ${escapeHTML(record.book.author)}</p>
                <div class="borrow-time">
                  <p><span class="time-label">Borrowed:</span> <span class="time-value">${borrowDateFormatted}</span></p>
                  <p><span class="time-label">Due Date:</span> <span class="${isOverdue ? "time-value-overdue" : "time-value"}">${dueDateFormatted} ${isOverdue ? "(OVERDUE)" : ""}</span></p>
                </div>
                <button class="btn-return" data-book-id="${record.book.id}">Return Book</button>
              </div>
            </div>
          `;
        }).join("")}
      </div>
    `;

    // Bind return button clicks
    listContainer.querySelectorAll(".btn-return").forEach(btn => {
      btn.addEventListener("click", (ev) => {
        const bookId = btn.getAttribute("data-book-id");
        try {
          returnBook(user.id, bookId);
          triggerSparklesAt(ev.clientX, ev.clientY);
          showToast("Book returned successfully!");
          renderDashboardView();
          renderBrowseView(); // update cache availability representation
        } catch (err) {
          showToast(err.message, "error");
        }
      });
    });
  }
}

// Admin Panel View Rendering
function renderAdminView() {
  const user = getCurrentUser();
  if (!user || user.role !== "admin") {
    navigateTo("view-auth");
    showToast("Access denied. Admin credentials required.", "error");
    return;
  }

  const tableBody = document.getElementById("admin-table-body");
  const books = getAllBooks();

  if (books.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 3rem;">
          No catalog records found. Create one using the "Add New Book" button.
        </td>
      </tr>
    `;
  } else {
    tableBody.innerHTML = books.map(book => `
      <tr>
        <td>
          <div class="admin-book-info">
            <div class="admin-table-cover">
              ${getBookCoverHTML(book)}
            </div>
            <div>
              <strong style="font-size:1.05rem; display:block; color:var(--color-secondary);">${escapeHTML(book.title)}</strong>
              <span style="font-size:0.85rem; color:var(--text-muted);">by ${escapeHTML(book.author)}</span>
            </div>
          </div>
        </td>
        <td><span class="tag tag-genre">${escapeHTML(book.genre)}</span></td>
        <td>${book.publishedYear}</td>
        <td>
          <div style="display:flex; align-items:center; gap:0.25rem;">
            <span style="color:#ffb400;">★</span> <span>${book.rating.toFixed(1)}</span>
          </div>
        </td>
        <td>
          <span class="book-status ${book.isAvailable ? "status-available" : "status-borrowed"}">
            ${book.isAvailable ? "Available" : "Borrowed"}
          </span>
        </td>
        <td>
          <div class="admin-actions">
            <button class="btn-edit" data-id="${book.id}" title="Edit Book">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
            </button>
            <button class="btn-delete" data-id="${book.id}" title="Delete Book">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
            </button>
          </div>
        </td>
      </tr>
    `).join("");

    // Bind edit / delete button actions
    tableBody.querySelectorAll(".btn-edit").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-id");
        openBookFormModal(id);
      });
    });

    tableBody.querySelectorAll(".btn-delete").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-id");
        const book = getBookById(id);
        if (confirm(`Are you sure you want to delete "${book.title}"?`)) {
          try {
            deleteBook(id);
            showToast("Book deleted successfully.");
            renderAdminView();
            renderHomeView();
            renderBrowseView();
            setupSearchAndFilters(); // Refresh genre counts in sidebar
          } catch (err) {
            showToast(err.message, "error");
          }
        }
      });
    });
  }
}

// Modal delegations for viewing book details or CRUD forms
function setupModalDelegations() {
  const detailModal = document.getElementById("modal-book-detail");
  const detailClose = document.getElementById("btn-close-detail-modal");
  const formClose = document.getElementById("btn-close-form-modal");
  const formModal = document.getElementById("modal-book-form");
  const addBtn = document.getElementById("btn-admin-add-book");

  // Close book details modal
  detailClose.addEventListener("click", () => {
    detailModal.classList.remove("active");
  });

  // Close crud form modal
  formClose.addEventListener("click", () => {
    formModal.classList.remove("active");
  });

  // Close modals on clicking outside content wrapper
  window.addEventListener("click", (e) => {
    if (e.target === detailModal) {
      detailModal.classList.remove("active");
    }
    if (e.target === formModal) {
      formModal.classList.remove("active");
    }
  });

  // Add Book button trigger (admin view)
  addBtn.addEventListener("click", () => {
    openBookFormModal();
  });
}

// Open Detail Modal
function openBookDetailModal(id) {
  const modal = document.getElementById("modal-book-detail");
  const modalBody = document.getElementById("book-detail-modal-body");
  const book = getBookById(id);
  const currentUser = getCurrentUser();

  if (!book) return;

  // Check if current logged-in user has borrowed this book
  let isBorrowedByCurrentUser = false;
  if (currentUser) {
    const activeBorrows = getActiveBorrowedBooks(currentUser.id);
    isBorrowedByCurrentUser = activeBorrows.some(record => record.bookId === book.id);
  }

  modalBody.innerHTML = `
    <div class="book-detail-cover">
      ${getBookCoverHTML(book)}
    </div>
    <div class="book-detail-info">
      <h3 class="book-detail-title">${escapeHTML(book.title)}</h3>
      <p class="book-detail-author">by ${escapeHTML(book.author)}</p>
      
      <div class="book-detail-tags">
        <span class="tag tag-genre">${escapeHTML(book.genre)}</span>
        <span class="tag tag-year">Published: ${book.publishedYear}</span>
        <span class="tag" style="color: #ffb400; background: rgba(255, 180, 0, 0.1);">★ ${book.rating.toFixed(1)}</span>
        <span class="tag tag-status ${book.isAvailable ? "status-available" : "status-borrowed"}">
          ${book.isAvailable ? "Available" : isBorrowedByCurrentUser ? "Borrowed by you" : "Borrowed (Out)"}
        </span>
      </div>

      <p class="book-detail-description">${escapeHTML(book.description)}</p>

      <div class="book-detail-footer">
        <div>
          ${!currentUser ? `<p style="font-size:0.85rem; color:var(--text-muted);">Please log in to borrow this book</p>` : ""}
        </div>
        ${
          book.isAvailable
            ? `<button class="btn-borrow" id="btn-modal-borrow" data-id="${book.id}">Borrow Book</button>`
            : isBorrowedByCurrentUser
              ? `<button class="btn-borrow" id="btn-modal-return" data-id="${book.id}" style="background-color: var(--color-secondary);">Return Book</button>`
              : `<button class="btn-borrow" disabled>Currently Borrowed</button>`
        }
      </div>
    </div>
  `;

  modal.classList.add("active");

  // Attach borrow/return buttons listeners in details modal
  const borrowBtn = document.getElementById("btn-modal-borrow");
  const returnBtn = document.getElementById("btn-modal-return");

  if (borrowBtn) {
    borrowBtn.addEventListener("click", (ev) => {
      if (!currentUser) {
        modal.classList.remove("active");
        navigateTo("view-auth");
        showToast("Please log in to borrow books.", "error");
        return;
      }

      try {
        borrowBook(currentUser.id, book.id);
        triggerSparklesAt(ev.clientX, ev.clientY);
        showToast(`Successfully borrowed "${book.title}"!`);
        modal.classList.remove("active");
        renderBrowseView();
        renderHomeView();
      } catch (err) {
        showToast(err.message, "error");
      }
    });
  }

  if (returnBtn) {
    returnBtn.addEventListener("click", (ev) => {
      try {
        returnBook(currentUser.id, book.id);
        triggerSparklesAt(ev.clientX, ev.clientY);
        showToast(`Successfully returned "${book.title}"!`);
        modal.classList.remove("active");
        renderBrowseView();
        renderHomeView();
      } catch (err) {
        showToast(err.message, "error");
      }
    });
  }
}

// Open CRUD Edit/Add Form modal
function openBookFormModal(id = null) {
  const modal = document.getElementById("modal-book-form");
  const titleHeader = document.getElementById("form-modal-title");
  const form = document.getElementById("form-book-crud");
  
  // Fields elements
  const inputId = document.getElementById("crud-book-id");
  const inputTitle = document.getElementById("crud-book-title");
  const inputAuthor = document.getElementById("crud-book-author");
  const selectGenre = document.getElementById("crud-book-genre");
  const inputYear = document.getElementById("crud-book-year");
  const inputRating = document.getElementById("crud-book-rating");
  const inputDescription = document.getElementById("crud-book-description");

  form.reset();

  if (id) {
    // Edit mode
    titleHeader.textContent = "Edit Catalog Item";
    const book = getBookById(id);
    if (!book) return;

    inputId.value = book.id;
    inputTitle.value = book.title;
    inputAuthor.value = book.author;
    selectGenre.value = book.genre;
    inputYear.value = book.publishedYear;
    inputRating.value = book.rating;
    inputDescription.value = book.description;
  } else {
    // Add mode
    titleHeader.textContent = "Add New Catalog Item";
    inputId.value = "";
    inputYear.value = new Date().getFullYear();
    inputRating.value = "4.5";
  }

  modal.classList.add("active");
}

// Set up form submission for CRUD
document.getElementById("form-book-crud").addEventListener("submit", (e) => {
  e.preventDefault();
  const id = document.getElementById("crud-book-id").value;
  const bookData = {
    title: document.getElementById("crud-book-title").value,
    author: document.getElementById("crud-book-author").value,
    genre: document.getElementById("crud-book-genre").value,
    publishedYear: document.getElementById("crud-book-year").value,
    rating: document.getElementById("crud-book-rating").value,
    description: document.getElementById("crud-book-description").value
  };

  try {
    if (id) {
      // Edit
      updateBook(id, bookData);
      showToast("Book updated successfully!");
    } else {
      // Add
      addBook(bookData);
      showToast("Book added to catalog!");
    }

    // Hide Modal, Refresh Admin Panel and Search list
    document.getElementById("modal-book-form").classList.remove("active");
    renderAdminView();
    renderHomeView();
    renderBrowseView();
    setupSearchAndFilters(); // Refresh genre counts in sidebar
  } catch (err) {
    showToast(err.message, "error");
  }
});

// Setup click delegation for all book cards across grids (Home, Browse)
function setupModalDelegationsForCards() {
  document.addEventListener("click", (e) => {
    const card = e.target.closest(".book-card");
    if (card) {
      const bookId = card.getAttribute("data-id");
      openBookDetailModal(bookId);
    }
  });
}
setupModalDelegationsForCards();
